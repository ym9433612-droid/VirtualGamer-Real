# GPU passthrough NVIDIA: ruta real

Para obtener aceleración 3D fuerte, el servidor debe tener una GPU física.
No existe una forma de crear una RTX 4090 virtual con el rendimiento de una 4090 usando solamente software y sin hardware equivalente.

La ruta habitual en Linux es:

1. Activar VT-d/IOMMU (Intel) o AMD-Vi/IOMMU (AMD) en BIOS/UEFI.
2. Activar IOMMU en GRUB.
3. Identificar la GPU y su función de audio.
4. Aislarlas mediante VFIO.
5. Pasarlas a QEMU.
6. Instalar el driver NVIDIA dentro de Windows.

Los parámetros exactos dependen del hardware del servidor, por lo que este directorio no modifica automáticamente GRUB ni desengancha GPUs.

Ejemplo de detección:

```bash
lspci -nn | grep -Ei 'nvidia|vga|audio'
```

Antes de hacer passthrough, asegúrate de que la GPU no sea la única GPU utilizada por el host para su escritorio.

El `dockurr/windows` backend soporta QEMU/KVM, pero el passthrough concreto debe adaptarse al host.
