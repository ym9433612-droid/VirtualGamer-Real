#!/usr/bin/env bash
set -e

echo "=== VirtualGamer Real: comprobación del host ==="

echo
echo "[1] CPU:"
nproc || true
lscpu | grep -E 'Model name|Virtualization' || true

echo
echo "[2] RAM:"
free -h

echo
echo "[3] Disco:"
df -h .

echo
echo "[4] KVM:"
if [ -e /dev/kvm ]; then
  ls -l /dev/kvm
else
  echo "ERROR: /dev/kvm no existe."
fi

if command -v kvm-ok >/dev/null 2>&1; then
  sudo kvm-ok || true
else
  echo "kvm-ok no está instalado. Instala cpu-checker."
fi

echo
echo "[5] Docker:"
docker --version || true
docker compose version || true

echo
echo "=== Fin de la comprobación ==="
