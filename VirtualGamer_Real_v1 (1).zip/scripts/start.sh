#!/usr/bin/env bash
set -e
mkdir -p windows shared
docker compose up -d
echo
echo "VM iniciada."
echo "Visor web: http://IP_DEL_SERVIDOR:8006"
echo "RDP:       IP_DEL_SERVIDOR:3389"
