# Cliente Android

Este APK/proyecto es el mando visual del servidor.

1. Pon la IP del servidor en `MainActivity.kt`.
2. Compila con Android Studio.
3. Instala el APK en el teléfono.
4. El APK abre el visor web de la VM.

Para juego normal, el RDP puede resultar más fluido que el visor web.
