# VirtualGamer Real v1

Este proyecto toma la arquitectura que aparece en el material de referencia:
**Android -> navegador/RDP -> servidor Linux -> Docker -> QEMU/KVM -> Windows**.

No es un simulador de hardware. La VM es real.

## Qué incluye

- Windows 11 Pro dentro de `dockurr/windows`.
- QEMU/KVM para aceleración de virtualización.
- 256 GB de RAM configurados como objetivo.
- 16 núcleos virtuales configurados como objetivo.
- Disco virtual de 10 TB configurado como objetivo.
- Red virtual.
- Audio para el visor web.
- RDP en el puerto 3389.
- Visor web en el puerto 8006.
- Carpeta `shared/` para intercambio de archivos.
- Script de comprobación del host.
- Cliente Android WebView para abrir el visor desde el teléfono.
- Configuración separada para GPU passthrough NVIDIA opcional.

## IMPORTANTE SOBRE LOS "256 GB / 10 TB / RTX 4090"

Los números no crean recursos de la nada.

El host Linux necesita disponer realmente de la RAM, almacenamiento y CPU que se asignen.
Si el host tiene 32 GB de RAM, no se pueden convertir físicamente en 256 GB reales.

La RTX 4090 tampoco puede existir como una GPU virtual con rendimiento de una 4090 sin una GPU física equivalente detrás.
Para juegos 3D serios, el camino real es **GPU passthrough** de una GPU NVIDIA física al guest, o una solución de aceleración gráfica compatible con el host.

Por eso este proyecto NO falsifica una "RTX 4090": deja preparada la VM real y ofrece el perfil de passthrough como opción.

## Requisitos del servidor

- Linux.
- Docker Engine + Docker Compose.
- CPU con virtualización habilitada.
- `/dev/kvm` disponible.
- Almacenamiento suficiente.
- Para el perfil completo: al menos 256 GB de RAM y 10 TB disponibles si realmente se quieren esos límites.
- Para gaming 3D: GPU física compatible y configuración de passthrough.

Comprobación rápida:

```bash
sudo apt update
sudo apt install -y cpu-checker
sudo kvm-ok
ls -l /dev/kvm
```

Debe aparecer:

```text
KVM acceleration can be used
```

## Arranque

```bash
mkdir -p ~/VirtualGamerReal
cd ~/VirtualGamerReal
unzip VirtualGamer_Real_v1.zip
chmod +x scripts/*.sh
./scripts/check_host.sh
docker compose up -d
```

Después abre desde Android:

```text
http://IP_DEL_SERVIDOR:8006
```

La primera instalación descarga e instala Windows automáticamente.

## RDP

Cuando Windows esté instalado, RDP es normalmente más fluido que el visor web.

Servidor:

```text
IP_DEL_SERVIDOR:3389
```

Usuario:

```text
Gamer
```

Contraseña:

```text
ChangeThisPassword123!
```

**Cambia la contraseña. No expongas 3389/8006 directamente a Internet sin protección.**

## GPU NVIDIA

El archivo:

```text
gpu-passthrough/README_ES.md
```

describe la ruta real para pasar una GPU física al guest.

No se activa automáticamente porque requiere adaptar IOMMU/GRUB a la placa, CPU y GPU concretas del servidor.

## Android

El proyecto:

```text
android-client/
```

es un cliente WebView muy ligero que abre el visor 8006 del servidor.

En:

```text
android-client/app/src/main/java/com/virtualgamer/client/MainActivity.kt
```

se puede cambiar la URL inicial.

El cliente no ejecuta QEMU en el teléfono: el teléfono actúa como pantalla/controlador de la VM real.

## Estructura

```text
VirtualGamer_Real_v1/
├── docker-compose.yml
├── .env.example
├── README_ES.md
├── scripts/
│   ├── check_host.sh
│   ├── start.sh
│   └── stop.sh
├── gpu-passthrough/
│   └── README_ES.md
├── shared/
└── android-client/
    ├── settings.gradle.kts
    ├── build.gradle.kts
    └── app/
        ├── build.gradle.kts
        └── src/main/
            ├── AndroidManifest.xml
            ├── java/com/virtualgamer/client/MainActivity.kt
            └── res/values/
                ├── strings.xml
                └── themes.xml
```

## Fuente de la arquitectura

El backend utilizado aquí se basa en el proyecto open-source `dockur/windows`.
